<?php

require_once DIEFINNHUTTE_CORE_ABS_PATH . '/core-dashboard/rest/rest.php';