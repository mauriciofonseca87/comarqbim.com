<div class="qodef-horizontal-timeline-wrapper">
    <div class="qodef-horizontal-timeline <?php echo esc_attr($holder_classes); ?>">
        <?php echo do_shortcode( $content ); ?>
    </div>
    <div class="qodef-horizontal-timeline-line"></div>
</div>