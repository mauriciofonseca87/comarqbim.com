<div class="qodef-clients-grid-holder qodef-grid-list qodef-disable-bottom-space <?php echo esc_attr( $holder_classes ); ?>">
	<div class="qodef-cg-inner qodef-outer-space">
		<?php echo do_shortcode( $content ); ?>
	</div>
</div>