<?php

include_once DIEFINNHUTTE_CORE_SHORTCODES_PATH . '/pricing-item-simple/functions.php';
include_once DIEFINNHUTTE_CORE_SHORTCODES_PATH . '/pricing-item-simple/pricing-item-simple.php';