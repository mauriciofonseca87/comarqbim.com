<?php

include_once DIEFINNHUTTE_CORE_CPT_PATH . '/testimonials/testimonials-register.php';
include_once DIEFINNHUTTE_CORE_CPT_PATH . '/testimonials/helper-functions.php';