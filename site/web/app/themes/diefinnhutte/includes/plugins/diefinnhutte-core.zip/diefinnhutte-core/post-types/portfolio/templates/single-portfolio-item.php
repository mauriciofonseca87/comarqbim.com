<?php

get_header();

diefinnhutte_select_get_title();

do_action('diefinnhutte_select_action_before_main_content');

diefinnhutte_core_get_single_portfolio();

get_footer();