<?php

include_once DIEFINNHUTTE_CORE_SHORTCODES_PATH . '/stamp/functions.php';
include_once DIEFINNHUTTE_CORE_SHORTCODES_PATH . '/stamp/stamp.php';