<article class="qodef-pl-item qodef-item-space <?php echo esc_attr( $this_object->getArticleClasses( $params ) ); ?>">
    <div class="qodef-pl-item-inner">
        <?php echo diefinnhutte_core_get_cpt_shortcode_module_template_part( 'portfolio', 'portfolio-list', 'layout-collections/vertical-item-showcase', '', $params ); ?>
    </div>
</article>