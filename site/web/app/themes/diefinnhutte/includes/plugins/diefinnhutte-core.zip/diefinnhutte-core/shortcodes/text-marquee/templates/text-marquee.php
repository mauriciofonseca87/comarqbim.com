<div class="qodef-text-marquee <?php echo esc_attr( $holder_classes ); ?>" <?php echo diefinnhutte_select_inline_style( $text_styles ); ?> <?php echo diefinnhutte_select_get_inline_attrs( $text_data ); ?>>
	<span class="qodef-marquee-element qodef-original-text"><?php echo esc_html( $text ) ?></span>
	<span class="qodef-marquee-element qodef-aux-text"><?php echo esc_html( $text ) ?></span>
</div>  